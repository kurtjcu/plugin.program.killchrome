# plugin.program.killchrome
Kodi addon to kill chrome window using xdotool for netflixmbc ( to be called via json-rpc)
